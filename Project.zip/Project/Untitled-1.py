from operator import contains
from queue import Empty
from tkinter import *
from tkinter.font import Font

from setuptools import Command
#ventana principal
app = Tk()
app.title("Rowy")
app.geometry("960x540")
#Fondos
imagen = PhotoImage(file = "1.png")
imagen2 = PhotoImage(file = "2.png")
#Pagína principal
def Mainmenu():
    #Lanzar la ventana Admin
    def Admin():
        for ele in app.winfo_children():
            ele.destroy()
        interfaz = Canvas(app)
        interfaz.pack()
        background2 = Label(interfaz, image = imagen2)
        background2.pack()
    #Comando boton Login
    def login ():
        c1 = txt1.get()
        c2 = txt2.get()
        if(c1 == "" or c2 == ""): #Campos vacios
            Error = Label(app, text= "Campos vacios", font = 20, fg= "#E41111", bg="#FAFBFD")
            Error.place(x= 514, y = 410)
        else:
            Admin()
    #Fondo ventana principal, botones y campos de textos
    background = Label(image = imagen, text = "fondo")
    background.place(x = 0, y = 0, relwidth = 1, relheight = 1)
    boton =Button(text="Login", command = login)
    boton.place(x=813, y=420)
    btn_font = Font(family="Hobo Std", size=12) 
    boton.configure(height = 2, 
          width = 12, bg="dark orange", font = btn_font)
    txt1 = Entry(app, bg="snow2")
    txt1.place(x = 514 , y= 200 , width= 400 , height= 54 )
    txt2 = Entry(app, bg="snow2")
    txt2.place(x = 514 , y= 326 , width= 400 , height= 54 )
#Lanzar ventana principal
Mainmenu()
app.mainloop()
